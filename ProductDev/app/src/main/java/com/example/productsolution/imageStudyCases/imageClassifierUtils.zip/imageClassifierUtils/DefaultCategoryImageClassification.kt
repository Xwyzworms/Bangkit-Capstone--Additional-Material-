package com.example.productsolution.imageStudyCases.imageClassifierUtils

data class DefaultCategoryImageClassification(
    var label : String,
    var score : Float,
    var index : Int
)
